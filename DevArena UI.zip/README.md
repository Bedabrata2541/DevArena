
  # DevArena UI

  This is a code bundle for DevArena UI. The original project is available at https://www.figma.com/design/ctDAAS8FXivZW1BsFkwB40/DevArena-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  